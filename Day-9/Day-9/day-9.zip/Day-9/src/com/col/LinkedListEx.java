package com.col;

import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList ll=new LinkedList();
		
		ll.add(34);
		ll.add(45.5);
		ll.add("shiva");
		System.out.println(ll);

	}

}
